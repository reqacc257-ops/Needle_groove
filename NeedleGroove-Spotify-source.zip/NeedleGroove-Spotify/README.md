# Needle & Groove — Spotify-inspired refresh

This project contains the updated Android app module.

## Changes
- Keeps the existing animated vinyl record and its album-art label.
- Keeps the existing song-artwork glow on the vinyl.
- Adds a song-responsive, animated dark gradient behind the Now Playing screen.
- Adds a persistent mini-player while browsing other tabs.
- Adds a queue dialog with play and remove actions.
- Adds a dedicated Search destination using the existing local library search.
- Uses Spotify-inspired dark surfaces and green accents by default.
- Adds subtle button press animations.
- Retains the existing timed/plain lyrics support and lyrics import workflow.

## Build
Open this folder in Android Studio and sync Gradle. The project uses Android Gradle Plugin 8.13.0, Java 17, and compile SDK 36.
Build with **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

The original uploaded archive contained the app module only (no Gradle wrapper or root project files), so root Android Studio project configuration has been added here.
